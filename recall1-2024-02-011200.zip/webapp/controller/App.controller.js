sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("recall1.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  