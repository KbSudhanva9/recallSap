/* global QUnit */

sap.ui.require(["recall1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
