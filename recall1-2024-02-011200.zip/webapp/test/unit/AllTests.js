sap.ui.define([
	"recall1/test/unit/controller/Screen1.controller"
], function () {
	"use strict";
});
